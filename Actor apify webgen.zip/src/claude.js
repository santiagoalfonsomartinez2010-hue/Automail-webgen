/**
 * Calls the Claude API to generate a professional, unique landing page
 * tailored to the business data scraped from Google Maps.
 */
export async function generateLandingPage(biz, apiKey) {
    const prompt = buildPrompt(biz);

    const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01',
            'content-type': 'application/json',
        },
        body: JSON.stringify({
            model: 'claude-sonnet-4-20250514',
            max_tokens: 4096,
            messages: [{ role: 'user', content: prompt }],
        }),
    });

    if (!res.ok) {
        const err = await res.text();
        throw new Error(`Claude API error ${res.status}: ${err}`);
    }

    const data = await res.json();
    const raw  = data.content[0].text;

    // Strip any markdown code fences if Claude added them
    return raw
        .replace(/^```html\s*/i, '')
        .replace(/^```\s*/i, '')
        .replace(/\s*```$/i, '')
        .trim();
}

function buildPrompt(biz) {
    const { name, category, address, phone, rating, reviews } = biz;

    const ratingLine = rating
        ? `- Valoración actual en Google Maps: ${rating}/5 (${reviews ?? '?'} reseñas)`
        : '';

    return `Eres un diseñador web profesional español. Crea una landing page HTML completa, moderna y de alta conversión para este negocio local.

DATOS DEL NEGOCIO:
- Nombre: ${name}
- Sector: ${category}
- Dirección: ${address}
- Teléfono: ${phone || 'No disponible'}
${ratingLine}

REQUISITOS TÉCNICOS:
- Un único archivo HTML autocontenido (CSS y JS inline, sin dependencias externas excepto Google Fonts)
- Totalmente responsive (mobile-first)
- Carga rápida: sin librerías pesadas

REQUISITOS DE DISEÑO:
- Diseño profesional con identidad visual coherente al sector (${category})
- Paleta de colores específica para el sector, no genérica
- Tipografía de Google Fonts apropiada (importar en el <head>)
- Hero section potente con headline y CTA
- Sección de servicios (infiere 4-6 servicios típicos del sector)
- Sección "Por qué elegirnos" con 3-4 puntos de valor
- Sección de contacto con el teléfono y dirección reales
- Footer profesional
- Micro-animaciones sutiles en scroll (vanilla JS, sin jQuery)
- Botón de WhatsApp flotante si hay teléfono disponible

REQUISITOS DE COPY:
- Todo en español
- Tono cercano y profesional
- Copy persuasivo orientado a conversión
- Título SEO relevante en el <title>

Devuelve ÚNICAMENTE el código HTML completo, empezando por <!DOCTYPE html>. Sin explicaciones, sin markdown, sin bloques de código.`;
}
