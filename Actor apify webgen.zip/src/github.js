/**
 * Publishes an HTML file to a GitHub Pages repository.
 *
 * Strategy:
 *   - Each business gets its own folder: /{slug}/index.html
 *   - The repo must have GitHub Pages enabled on the main branch
 *   - URL format: https://{githubUser}.github.io/{githubRepo}/{slug}/
 */
export async function publishToGitHub({ html, bizName, githubToken, githubUser, githubRepo }) {
    const slug    = toSlug(bizName);
    const path    = `${slug}/index.html`;
    const content = Buffer.from(html).toString('base64');
    const apiBase = `https://api.github.com/repos/${githubUser}/${githubRepo}/contents/${path}`;

    const headers = {
        Authorization: `Bearer ${githubToken}`,
        Accept:        'application/vnd.github+json',
        'Content-Type': 'application/json',
        'X-GitHub-Api-Version': '2022-11-28',
    };

    // Check if the file already exists (need the SHA to update it)
    let sha;
    try {
        const check = await fetch(apiBase, { headers });
        if (check.ok) {
            const existing = await check.json();
            sha = existing.sha;
        }
    } catch {
        // File doesn't exist yet — that's fine
    }

    // Create or update the file
    const body = {
        message: `automail: landing page para ${bizName}`,
        content,
        ...(sha ? { sha } : {}),
    };

    const res = await fetch(apiBase, {
        method:  'PUT',
        headers,
        body:    JSON.stringify(body),
    });

    if (!res.ok) {
        const err = await res.text();
        throw new Error(`GitHub API error ${res.status}: ${err}`);
    }

    return `https://${githubUser}.github.io/${githubRepo}/${slug}/`;
}

/** Converts a business name to a URL-safe slug */
function toSlug(name) {
    return name
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')   // strip accents
        .replace(/[^a-z0-9\s-]/g, '')      // remove special chars
        .trim()
        .replace(/\s+/g, '-')              // spaces to hyphens
        .replace(/-+/g, '-')               // collapse double hyphens
        .substring(0, 60);
}
