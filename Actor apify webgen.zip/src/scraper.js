import { ApifyClient } from 'apify-client';
import { Actor } from 'apify';

/**
 * Scrape Google Maps for businesses without a website.
 * Uses the xmiso_scrapers/businesses-without-websites-leads-scraper-google-maps Actor.
 */
export async function scrapeBusinesses({ ciudad, categoria, cantidad }) {
    const token = process.env.APIFY_TOKEN;
    const client = new ApifyClient({ token });

    console.log(`🗺️  Buscando "${categoria}" en "${ciudad}"...`);

    const run = await client
        .actor('xmiso_scrapers/businesses-without-websites-leads-scraper-google-maps')
        .call({
            searchQuery: `${categoria} en ${ciudad}`,
            maxResults: cantidad,
            countryCode: 'ES',
        });

    const { items } = await client
        .dataset(run.defaultDatasetId)
        .listItems();

    // Normalize fields — the Actor may return different key names
    return items.map(item => ({
        name:     item.title     || item.name     || 'Negocio sin nombre',
        phone:    normalizePhone(item.phone       || item.phoneNumber || ''),
        address:  item.address   || item.location || '',
        category: item.category  || item.type     || categoria,
        rating:   item.rating    || null,
        reviews:  item.reviewsCount || null,
    }));
}

/**
 * Convert Spanish local numbers to E.164 (+34XXXXXXXXX) for Twilio.
 * Leaves numbers that are already in E.164 format unchanged.
 */
function normalizePhone(raw) {
    if (!raw) return '';
    const digits = raw.replace(/\D/g, '');
    if (digits.startsWith('34') && digits.length === 11) return `+${digits}`;
    if (digits.length === 9 && /^[6789]/.test(digits)) return `+34${digits}`;
    if (digits.length > 9) return `+${digits}`;
    return raw; // return as-is if we can't normalize
}
