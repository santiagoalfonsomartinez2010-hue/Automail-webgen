import { Actor } from 'apify';
import { generateLandingPage } from './claude.js';
import { publishToGitHub } from './github.js';
import { sendWhatsApp } from './twilio.js';
import { scrapeBusinesses } from './scraper.js';

await Actor.init();

const input = await Actor.getInput();
const {
    ciudad = 'Madrid',
    categoria = 'clinica fisioterapia',
    cantidad = 10,
    anthropicKey,
    githubToken,
    githubUser,
    githubRepo,
    twilioSid,
    twilioToken,
    twilioFrom,
} = input;

console.log(`🚀 Iniciando AUTOMAIL WebGen`);
console.log(`📍 Ciudad: ${ciudad} | Categoría: ${categoria} | Cantidad: ${cantidad}`);

// ── 1. SCRAPE ──────────────────────────────────────────────────────────────
const businesses = await scrapeBusinesses({ ciudad, categoria, cantidad });
console.log(`✅ ${businesses.length} negocios sin web encontrados`);

// ── 2. GENERAR + PUBLICAR + CONTACTAR ────────────────────────────────────
const results = [];

for (const biz of businesses) {
    console.log(`\n🔄 Procesando: ${biz.name}`);

    try {
        // 2a. Generar landing page con Claude
        const html = await generateLandingPage(biz, anthropicKey);
        console.log(`  ✏️  Landing page generada`);

        // 2b. Publicar en GitHub Pages
        const pageUrl = await publishToGitHub({
            html,
            bizName: biz.name,
            githubToken,
            githubUser,
            githubRepo,
        });
        console.log(`  🌐 Publicada en: ${pageUrl}`);

        // 2c. Enviar WhatsApp
        let whatsappStatus = 'no_phone';
        if (biz.phone) {
            whatsappStatus = await sendWhatsApp({
                to: biz.phone,
                bizName: biz.name,
                pageUrl,
                twilioSid,
                twilioToken,
                twilioFrom,
            });
            console.log(`  📱 WhatsApp: ${whatsappStatus}`);
        }

        results.push({
            name: biz.name,
            phone: biz.phone || '—',
            address: biz.address || '—',
            category: biz.category || categoria,
            pageUrl,
            whatsappStatus,
            status: 'completado',
            timestamp: new Date().toISOString(),
        });

    } catch (err) {
        console.error(`  ❌ Error con ${biz.name}: ${err.message}`);
        results.push({
            name: biz.name,
            phone: biz.phone || '—',
            status: 'error',
            error: err.message,
            timestamp: new Date().toISOString(),
        });
    }

    // Pausa entre negocios para no saturar APIs
    await new Promise(r => setTimeout(r, 2000));
}

// ── 3. OUTPUT ─────────────────────────────────────────────────────────────
await Actor.pushData(results);

const completed = results.filter(r => r.status === 'completado').length;
const errors    = results.filter(r => r.status === 'error').length;

console.log(`\n🎯 RESUMEN FINAL`);
console.log(`   ✅ Completados: ${completed}`);
console.log(`   ❌ Errores:     ${errors}`);
console.log(`   📊 Total:       ${results.length}`);

await Actor.exit();
